# Riverbend (Android)

A WebView wrapper around the Riverbend canoe game. The game itself is `app/src/main/assets/index.html`.

## Build the APK without installing anything (GitHub)
1. Create a new repository on github.com and upload the contents of this folder (keep the `.github` folder).
2. Open the repository's **Actions** tab. The "Build APK" run starts on upload (or press **Run workflow**).
3. When it finishes (about 3–5 minutes), open the run and download **riverbend-apk**. Unzip it to get `app-debug.apk`.

## Build with Android Studio
Open this folder in Android Studio, let it sync, then choose **Build > Build APK(s)**.
The APK lands in `app/build/outputs/apk/debug/`.

## Install on your phone
Copy `app-debug.apk` to the phone, open it, and allow installs from that source when Android asks.
This is a debug build, which is fine for personal use; publishing to Google Play needs a signed release build.

## Updating the game
Replace `app/src/main/assets/index.html` with the new version and rebuild.
